﻿using System;

public class WebServiceAPI
{
	public WebServiceAPI()
	{
        //I am a generic API that does nothing because you
        // did not ask
	}
}
