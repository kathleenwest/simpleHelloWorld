﻿using System;

public class WindowsServicesAPI
{
	public WindowsServicesAPI()
	{
        //I am a generic API
	}
}
