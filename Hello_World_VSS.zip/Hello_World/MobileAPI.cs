﻿using System;

public class MobileAPI
{
	public MobileAPI()
	{
        //I am a generic API that does nothing because you did not ask
	}
}
