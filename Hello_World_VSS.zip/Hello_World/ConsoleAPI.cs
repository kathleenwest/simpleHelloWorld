﻿using System;

public class ConsoleAPI
{
	public ConsoleAPI()
	{
        // I am a generic console API class that does nothing yet
        // because you did not ask me too
	}
}
