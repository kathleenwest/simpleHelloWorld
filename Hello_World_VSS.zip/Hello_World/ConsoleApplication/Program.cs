﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            // No implementation needed here
            // Can be Future 
            // Everything works in Main Hello_World Project
        }
    }

    // Demonstrate design and class structure requirements
    public class MyConsole
    {
        internal StringBuilder myMessage;
        public MyConsole(string message)
        {
            myMessage = new StringBuilder(message);
        }

        public void Write()
        {
            Console.WriteLine("Business Requirement: {0}", myMessage.ToString());
            Console.WriteLine("Press Any Key To Exit....");
            Console.ReadLine();
        }

        // This is written for the unit test
        public string getMyMessage()
        {
            return myMessage.ToString();
        }
    }

    // This is the implementation of the class template above
    public class MyConsoleHelloWorld : MyConsole
    {

        public MyConsoleHelloWorld(string message) : base(message)
        {
            // This calls the base class constructor first
            // We will use the inherited base properties
            // to demonstrate we know how to use inheritance
        }

    }

}
