﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using ConsoleApplication;


namespace Hello_World
{
    class Program
    {
        static void Main(string[] args)
        {
            MyConsoleHelloWorld myApp = new MyConsoleHelloWorld("Hello World");
            myApp.Write();         
        }
    }
    


 




}
