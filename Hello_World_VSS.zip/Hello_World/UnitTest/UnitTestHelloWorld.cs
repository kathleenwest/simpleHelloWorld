﻿using System;
using Hello_World;
using ConsoleApplication;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
    [TestClass]
    public class UnitTestHelloWorld
    {
        [TestMethod]
        public void TestMethod()
        {
            // arrange
            string expected = "Hello World";
            MyConsoleHelloWorld myApp = new MyConsoleHelloWorld(expected);

            // act
            myApp.Write();

            // assert
            string actual = myApp.getMyMessage();
            Assert.AreEqual(expected, actual, false, "Unit Test Failed");
        }
    }
}
